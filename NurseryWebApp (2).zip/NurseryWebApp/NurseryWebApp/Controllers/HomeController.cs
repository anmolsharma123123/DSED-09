﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NurseryWebApp.Data;
using NurseryWebApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace NurseryWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public HomeController(ApplicationDbContext context, UserManager<IdentityUser> userManager, ILogger<HomeController> logger)
        {
            _logger = logger;
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public async Task<IActionResult> ViewItemBySubCategory(int? id)
        {
            var subcategory = await _context.SubCategories.FindAsync(id);
            ViewData["SubCategoryName"] = "None";
            if (subcategory != null)
            {
                ViewData["SubCategoryName"] = subcategory.SubCategoryName;
            }
            var applicationDbContext = _context.Plants
                .Include(j => j.SubCategory)
                .Where(m => m.SubCategoryID == id);
            return View(await applicationDbContext.ToListAsync());
        }

        [Authorize]
        public async Task<IActionResult> MyReviews()
        {
            string userid = _userManager.GetUserName(this.User);
            var applicationDbContext = _context.PlantReviews
                .Include(j => j.Plant)
                .Where(m => m.UserID == userid);
            return View(await applicationDbContext.ToListAsync());
        }

        public async Task<IActionResult> ViewDetails(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plant = await _context.Plants
                .Include(i => i.SubCategory)
                .Include(i => i.PlantReviews)
                .FirstOrDefaultAsync(m => m.PlantID == id);
            if (plant == null)
            {
                return NotFound();
            }

            return View(plant);
        }

        [Authorize]
        public IActionResult AddReview(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var plantInfo = _context.Plants
                .FirstOrDefault(m => m.PlantID == id);
            if (plantInfo == null)
            {
                return NotFound();
            }

            ViewData["PlantID"] = plantInfo.PlantID;
            ViewData["PlantName"] = plantInfo.PlantName;
            return View();
        }

        // POST: JewelleryReviews/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddReview([Bind("ReviewID,ReviewTitle,Address,PlantID")] PlantReview plantReview)
        {
            ModelState.Remove("UserID");
            ModelState.Remove("ReviewDate");
            if (ModelState.IsValid)
            {
                plantReview.UserID = _userManager.GetUserName(this.User);
                plantReview.ReviewDate = DateTime.Now;
                _context.Add(plantReview);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PlantID"] = plantReview.PlantID;
            return View(plantReview);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
