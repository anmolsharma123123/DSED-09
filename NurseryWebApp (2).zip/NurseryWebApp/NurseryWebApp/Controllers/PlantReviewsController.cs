﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NurseryWebApp.Data;
using NurseryWebApp.Models;

namespace NurseryWebApp.Controllers
{
    public class PlantReviewsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PlantReviewsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: PlantReviews
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.PlantReviews.Include(p => p.Plant);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: PlantReviews/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plantReview = await _context.PlantReviews
                .Include(p => p.Plant)
                .FirstOrDefaultAsync(m => m.PlantReviewID == id);
            if (plantReview == null)
            {
                return NotFound();
            }

            return View(plantReview);
        }

        // GET: PlantReviews/Create
        public IActionResult Create()
        {
            ViewData["PlantID"] = new SelectList(_context.Plants, "PlantID", "Description");
            return View();
        }

        // POST: PlantReviews/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlantReviewID,UserID,ReviewDate,ReviewTitle,Address,PlantID")] PlantReview plantReview)
        {
            if (ModelState.IsValid)
            {
                _context.Add(plantReview);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PlantID"] = new SelectList(_context.Plants, "PlantID", "Description", plantReview.PlantID);
            return View(plantReview);
        }

        // GET: PlantReviews/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plantReview = await _context.PlantReviews.FindAsync(id);
            if (plantReview == null)
            {
                return NotFound();
            }
            ViewData["PlantID"] = new SelectList(_context.Plants, "PlantID", "Description", plantReview.PlantID);
            return View(plantReview);
        }

        // POST: PlantReviews/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlantReviewID,UserID,ReviewDate,ReviewTitle,Address,PlantID")] PlantReview plantReview)
        {
            if (id != plantReview.PlantReviewID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(plantReview);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PlantReviewExists(plantReview.PlantReviewID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PlantID"] = new SelectList(_context.Plants, "PlantID", "Description", plantReview.PlantID);
            return View(plantReview);
        }

        // GET: PlantReviews/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plantReview = await _context.PlantReviews
                .Include(p => p.Plant)
                .FirstOrDefaultAsync(m => m.PlantReviewID == id);
            if (plantReview == null)
            {
                return NotFound();
            }

            return View(plantReview);
        }

        // POST: PlantReviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var plantReview = await _context.PlantReviews.FindAsync(id);
            _context.PlantReviews.Remove(plantReview);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PlantReviewExists(int id)
        {
            return _context.PlantReviews.Any(e => e.PlantReviewID == id);
        }
    }
}
