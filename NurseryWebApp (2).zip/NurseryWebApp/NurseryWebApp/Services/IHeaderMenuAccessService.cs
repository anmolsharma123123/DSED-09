﻿using NurseryWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NurseryWebApp.Services
{
    public interface IHeaderMenuAccessService
    {
        Task<List<Category>> GetHeaderMenu();
    }
}
