﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace NurseryWebApp.Models
{
    public class Plant
    {
        [Key]
        public int PlantID { get; set; }

        [Required]
        [StringLength(200)]
        [Display(Name = "Plant Name")]
        public string PlantName { get; set; }

        [Required]
        [Display(Name = "Plant Price")]
        public float Price { get; set; }

        [Required]
        [StringLength(1500)]
        [Display(Name = "Description")]
        public string Description { get; set; }


        [Required]
        [StringLength(1500)]
        [Display(Name = "Feature")]
        public string ItemFeature { get; set; }

        [Required]
        public int SubCategoryID { get; set; }

        [ForeignKey("SubCategoryID")]
        [InverseProperty("Plants")]
        public virtual SubCategory SubCategory { get; set; }

        [Required]
        [StringLength(20)]
        public string Extension { get; set; }

        [NotMapped]
        public PhotoUpload File { get; set; }

        public virtual ICollection<PlantReview> PlantReviews { get; set; }
    }

    public class PhotoUpload
    {
        [Required]
        [Display(Name = "Plant Photo")]
        public IFormFile FormFile { get; set; }
    }
}
