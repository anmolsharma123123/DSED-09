﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace NurseryWebApp.Models
{
    public class PlantReview
    {
        [Key]
        public int PlantReviewID { get; set; }

        [Required]
        [Display(Name = "User ID")]
        public string UserID { get; set; }

        [Display(Name = "Review Date")]
        public DateTime ReviewDate { get; set; }

        [Display(Name = "Review Title")]
        public string ReviewTitle { get; set; }

        [StringLength(1500)]
        [Display(Name = "Review Text")]
        public string Address { get; set; }

        [Required]
        public int PlantID { get; set; }

        [ForeignKey("PlantID")]
        [InverseProperty("PlantReviews")]
        public virtual Plant Plant { get; set; }
    }
}
