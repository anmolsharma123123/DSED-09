INSERT [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp]) VALUES (N'216d0948-d6c2-4a3c-a025-bcc2d56194c0', N'admin', N'admin', N'3c2836ab-41a8-41b6-b0bf-7351734d3bf0')
GO
INSERT [dbo].[AspNetUsers] ([Id], [UserName], [NormalizedUserName], [Email], [NormalizedEmail], [EmailConfirmed], [PasswordHash], [SecurityStamp], [ConcurrencyStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEnd], [LockoutEnabled], [AccessFailedCount]) VALUES (N'8f5242e6-4954-4cae-9c85-bef0e527c63c', N'leo@gmail.com', N'LEO@GMAIL.COM', N'leo@gmail.com', N'LEO@GMAIL.COM', 1, N'AQAAAAEAACcQAAAAELrwLSfbEGE9aJS7h/XBjWMlPmay45kRguzcyvQt0keeR8qedXGFcLuufVeYEtRR8w==', N'4HSXFZT6Y6JGHC4KRHU56RPSLFIJLFHH', N'0e59823d-cbf0-43e2-8213-f44dd98f0853', NULL, 0, 0, NULL, 1, 0)
GO
INSERT [dbo].[AspNetUsers] ([Id], [UserName], [NormalizedUserName], [Email], [NormalizedEmail], [EmailConfirmed], [PasswordHash], [SecurityStamp], [ConcurrencyStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEnd], [LockoutEnabled], [AccessFailedCount]) VALUES (N'a146ec6c-c693-4c9b-bea0-dbc1c74db92c', N'admin@gmail.com', N'ADMIN@GMAIL.COM', N'admin@gmail.com', N'ADMIN@GMAIL.COM', 1, N'AQAAAAEAACcQAAAAEKO2b8jhgbTkkbA1aNEJ3EK9qCNEcqnLisMPFDTOewrh+pKLS4rwkxkYK3aeoW7mYQ==', N'6JIYMFNCJFS7SAU24O63KOHK6WU4ONUK', N'78f09705-a62e-47ad-b29b-8b671a763689', NULL, 0, 0, NULL, 1, 0)
GO
INSERT [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'a146ec6c-c693-4c9b-bea0-dbc1c74db92c', N'216d0948-d6c2-4a3c-a025-bcc2d56194c0')
GO
SET IDENTITY_INSERT [dbo].[Categories] ON 
GO
INSERT [dbo].[Categories] ([CategoryID], [CategoryName]) VALUES (1, N'Plants')
GO
INSERT [dbo].[Categories] ([CategoryID], [CategoryName]) VALUES (2, N'Seeds')
GO
INSERT [dbo].[Categories] ([CategoryID], [CategoryName]) VALUES (4, N'Planters')
GO
SET IDENTITY_INSERT [dbo].[Categories] OFF
GO
SET IDENTITY_INSERT [dbo].[SubCategories] ON 
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (1, N'Air Plants', 1)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (2, N'Aquatic Plants', 1)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (3, N'Cactus Plants', 1)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (4, N'Flower Seeds', 2)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (5, N'Vegetable / Herb Seed', 2)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (6, N'Bamboo Seeds', 2)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (7, N'Growers Planters', 4)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (8, N'Cute Planters', 4)
GO
INSERT [dbo].[SubCategories] ([SubCategoryID], [SubCategoryName], [CategoryID]) VALUES (9, N'Black Planters', 4)
GO
SET IDENTITY_INSERT [dbo].[SubCategories] OFF
GO
SET IDENTITY_INSERT [dbo].[Plants] ON 
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (1, N'Living Granite - Air Plant', 7.49, N'Make your world elegant and beautiful with the Living granite air plant product containing granite planter and tillandsia Ionantha air plant.

Ionantha:It is an extra adorable air plant features layers of the softest, fuzziest leaves. Absolutely unlike any other air plant. The silvery-white colored "fuzz", also known as trichomes, naturally reflects sunlight, which essentially shields the plant from direct sunlight to help it from drying out.

The multi-color granite rock planters with hardy tillandsia air plants is an amazing product and the air plant is mostly mistaken for being artificial as they are attractive and require no size. They produce oxygen and reduce dust. They increase the quality of the air and increase the green cover. These plants are known to improve concentration and productivity, reduce stress and boost your mood.The dimension of Granite planters: Approx.5 x 1.5 x 2 inch (l X b X h).The color of the granite planter may vary as per the availability.', N'These multicolor rock planters with elegant plants will increase the beauty of any interior space whether it is home or office', 1, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (2, N'Ananas - Air Plant', 8.99, N'Make your world elegant and beautiful with the Ananas air plant product contains ananas shaped ceramic pot with hand placed hardy Brachycaulos tillandsia air plant.

The brachycaulos air plant is wide, thick with strong leaves that are an incredible and vibrant green, the Tillandsia Brachycaulos resembles like a pineapple from the top portion. It will produce many layers of strong leaves that change their color as it grows.

It will also develop luscious red and pink hues when the plant blooms. The flowers themselves are a beautiful purple with slight yellow coloring. It is also one of the few varieties of Air Plants that can manage the strong rays of the sun, and develop new colors when exposed to direct, natural light. The ananas shaped ceramic pot with a hand placed hardy tillandsia air plants is an amazing product and are mostly mistaken for being artificial as they are attractive and require no size. They produce oxygen and reduce dust. They increase the quality of the air and increase the green cover. These plants are known to improve concentration and productivity, reduce stress and boost your mood.The dimension of a ceramic pot: Approx. 4 x 4 x 5 inch (l X b X h).', N'When the Tillandsia blooms, it will have the most beautiful violet flowers, and when in bloom the top of the plant will also turn a brilliant bright red.
The ananas shaped ceramic pot with hardy tillandsia air plants is an elegant product increase the beauty of your home, office or any empty space.', 1, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (3, N'Tree of Life - Air Plant', 8.99, N'Make your world elegant and beautiful with the Tree of life air plant product in which you will get hand carved wood with hardy Brachycaulos tillandsia air plant.

The brachycaulos air plant is wide, thick with strong leaves that are an incredible and vibrant green, the Tillandsia Brachycaulos resembles like a pineapple from the top portion. It will produce many layers of strong leaves that change their color as it grows.

It will also develop luscious red and pink hues when the plant blooms. The flowers themselves are a beautiful purple with slight yellow coloring. It is also one of the few varieties of Air Plants that can manage the strong rays of the sun, and develop new colors when exposed to direct, natural light. The hand-carved wood with hardy tillandsia air plants is an amazing product and this air plant is mostly mistaken for being artificial as they are attractive and require no size. They produce oxygen and reduce dust. They increase the quality of the air and increase the green cover. These plants are known to improve concentration and productivity, reduce stress and boost your mood.The dimension of a hand carved wood: Approx. 4 x 4 x 3 inch ( l X b X h).', N'When the Tillandsia blooms, it will have the most beautiful violet flowers, and when in bloom the top of the plant will also turn a brilliant bright red.
The hand-carved wood with hardy tillandsia air plants is an elegant product increase the beauty of your home, office or any empty space.', 1, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (4, N'Water Cabbage, Water Lettuce (3 Piece) - Plant', 1.99, N'Cabbage

1 packet contains Cabbage - 100 seeds.

Cabbage (Brassica oleracea or variants) is a leafy green biennial plant, grown as an annual vegetable crop for its dense-leaved heads. Closely related to other cole crops, such as broccoli, cauliflower, and brussels sprouts, it descends from B. oleracea var. oleracea, a wild field cabbage.

Cabbage heads generally range from 1 to 8 pounds (0.5 to 4 kg), and can be green, purple and white. Smooth-leafed firm-headed greencabbages are the most common, with smooth-leafed red and crinkle-leafed savoy cabbages of both colors seen more rarely.This cool-season crop grows best when daytime temperatures are in the 60s F. Direct-seed or transplant spring crops for fresh use in summer.Plant fall crops for winter storage or sauerkraut.Lifecycle: annualEase-of-care: moderately difficult, Requires good soil, timely planting and protection from pests.', N'Cabbage is prepared and consumed in many ways
The simplest options include eating the vegetable raw or steaming it, though many cuisines pickle, stew, sautÃƒÆ’Ã†â€™ ©e or braise cabbage
Pickling is one of the most popular ways of preserving cabbage, creating dishes such as sauerkraut and kimchee, although kimchee is more often made from Chinese cabbage
Savoy cabbages are usually used in salads, while smooth-leaf types are utilized for both market sales and processing
Bean curd and cabbage is a staple of Chinese cooking, while the British dish bubble and squeak is made primarily with salt beef and boiled cabbage', 2, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (5, N'Water Lily (Any Color) - Plant', 2.39, N'It is one of the most majestic plants to have in a water garden. It is by far the most exotic of all pond plants.

Best grown in moist, acidic, humusy soils in part shade to full shade. Plants may be grown from seed, but will not flower for 4-5 years. Quicker and better results are obtained from planting corms which are sold by many bulb suppliers and nurseries.

In addition, offsets from mature plants may be harvested and planted.', N'Naturalize in moist soils in shaded areas of native plant gardens, shade gardens, woodland gardens or wild/naturalized areas. Also grows well in pond or stream banks or in shady areas of rock gardens.', 2, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (6, N'Umbrella Sedge - Plant', 2.99, N'Sedges have edges, goes the old botanical rhyme, and that is the way to distinguish sedge from other ornamental grasses. The green sedge stalks are triangular and squared off at the corners.

Umbrella sedges, ornamental grasses belonging to the Cyperaceae family, are herbaceous perennials commonly grown in backyard containers and water gardens. These aquatic plants flourish in the moist wetland soil at creeks and pond edges, and can help hold wet soil together, especially around water sources with sloping banks.

Umbrella sedges come in a variety of types, including a popular dwarf variety (Cyperus albostriatus) and the larger Cyperus involucratus. They tend to grow quickly, often overpowering their original planting location, and require some yearly trimming.', N'The tubers are credited with astringent, diaphoretic, diuretic, dessicant, cordial and stomachic properties
A decoction of the tuber is used for washing hair, treating gonorrhea and syphilis
It is also given in diarrhea and for general weakness', 2, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (7, N'Acanthocereus tetragonus - Cactus Plant', 2.99, N'Acanthocereus tetragonus flowers bloom at night and close during the day.

Constituents

Acanthocereus tetragonus - Cactus Plant- 1
3 inch (8 cm) Grower Round Plastic Pot (Black)- 1
3.3 inch (8 cm) Square Plastic Planter with Rounded Edges (Red)- 1
Acanthocereus tetragonus is a tall, columnar cactus. Stems are dark green, have three to five angles. Flowers are open from midnight until dawn, attracting hummingbird moths.', N'Acanthocereus tetragonus is used as the ornamental plant', 3, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (8, N'Echinopsis chamaecereus - Cactus Plant', 3.49, N'chinopsis chamaecereus is a type of cactus which is drought tolerant and grows somewhat cylindrical.', N'Survivals and growers of the summer.', 3, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (9, N'Opuntia monacantha - Cactus Plant', 2.99, N'Opuntia is a type of cactus which is drought tolerant and grows somewhat cylindrical. It has an appearance with numerous small cylindrical tubercles. It is a bushy cactus with cylindrical branches. Flowers are generally large and are born individually on the areoles.', N'Survivals and growers of the summer.', 3, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (10, N'Amaranthus Tricolour Mixed Color - Desi Flower Seeds', 2.5, N'Decorated your garden with an attractive foliage Amaranthus plant. The seed packet contains approx. 35 seeds.

Amaranthus tricolor mixed is a very usefully as a temporary shrub. Attractive bright foliage plant blooms in after spring has faded. It goes by common names such as love-lies-bleeding, pendant amaranth, tassel flower, velvet flower, foxtail amaranth, and Quilete.', N'May be used in beds or borders. Interesting edging along walks or paths.', 4, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (11, N'Amaranthus Cadatus Red - Desi Flower Seeds', 5.5, N'Decorated your garden with an annual flowering Amaranthus plant. The seed packet contains approx. 35 seeds.

Amaranthus caudatus mixed is a very usefully as a temporary shrub. Amaranthus caudatus is a species of annual flowering plant. It goes by common names such as love-lies-bleeding, pendant amaranth, tassel flower, velvet flower, foxtail amaranth, and Quilete.', N'May be used in beds or borders. Interesting edging along walks or paths.', 4, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (12, N'Balsam Double Mixed Color - Desi Flower Seeds', 5.5, N'Balsam flower resemble with mini roses thickly spaced petals and tones. The seed packet contains 35 seeds.

The balsam plant has a soft, fleshy stem; and spirally arranged long pointed leaves.', N'Discovered in South East Asia, Balsam is an old-fashioned annual that produces single or double flowers in the leaf axils along the main stem of the plant from summer to early autumn. A great bedding annual plant.', 4, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (13, N'Coriander Green Aroma ', 5.5, N'All parts of the Coriander is used in cooking. 1 packet contains approximately 35 seeds.

Coriander is a fast-growing, aromatic herb that grows in the cooler weather of spring and fall. Coriander seed is technically a fruit containing two seeds in it.', N'It adds flavor to the food.', 5, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (14, N'Spinach All Green', 5.5, N'The Spinach is a most common vegetable in many food cultures. This packet contains approximately 35 seeds.

Spinach has similar growing conditions and requirements as lettuce, but it is more versatile in both its nutrition and its ability to be eaten raw or cooked.', N'Spinach leaves give shades of green when used as a natural dye.', 5, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (15, N'Cabbage Special Pride', 5.5, N'This Cabbage, leafy vegetable contains a good amount of nutrition. This pack contains approximately 35 seeds.

Cabbage (Brassica oleracea or variants) is a leafy green annual-biennial plant, grown as an annual vegetable crop for its dense-leaved heads.Cabbage heads generally range from 1 to 8 pounds (0.5 to 4 kg) and can be green, purple and white.

Smooth-leafed firm-headed greencabbages are the most common, with smooth-leafed red and crinkle-leafed savoy cabbages of both colors seen more rarely.This cool-season crop grows best when daytime temperatures are in the 60s F. Direct-seed or transplant spring crops for fresh use in summer.Plant fall crops for winter storage or sauerkraut.', N'Cabbage is prepared and consumed in many ways
The simplest options include eating the vegetable raw or steaming it, though many cuisines pickle, stew, or braised cabbage', 5, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (16, N'Bambusa Arundinacea - 0.5 kg Seeds', 11.83, N'Also known as: Spiny bamboo, Thorny bamboo, Tziu chu, Kalak, Bans', N'Not Mention', 6, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (17, N'Dendrocalamus Strictus, Solid Bamboo - 0.5 kg Seeds', 19.75, N'Common name: Male Bamboo, Dolid Bamboo', N'Not Mention', 6, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (18, N'Lucky Bamboo - 5 Seeds', 2.17, N'1 pack contains 5 seeds of Lucky Bamboo.', N'Not Mention', 6, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (19, N'17.7 inch (45 cm) Bowl No. 45 Round Plastic Pot (Violet) (set of 3)', 12.49, N'The best quality, beautiful and high-quality plastic bowls. Having professional bottom design with top classgrowers.

Heavy duty pot which is durable, long lasting, and elegantly stable.This pot has sufficient drainage holes at the bottom, which helps to avoid the overwatering to the plant.', N'Wipe out with soft and dry cloth, store in clean and dry place, handle with firm hands.', 7, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (20, N'17.7 inch (45 cm) Bowl No. 45 Round Plastic Pot (Dark Pink) (set of 3)', 12.49, N'The best quality, beautiful and high-quality plastic bowls. Having professional bottom design with top classgrowers.

Heavy duty pot which is durable, long lasting, and elegantly stable.This pot has sufficient drainage holes at the bottom, which helps to avoid the overwatering to the plant.', N'Not Mention', 7, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (21, N'17.7 inch (45 cm) Bowl No. 45 Round Plastic Pot (Lime Yellow) (set of 3)', 12.49, N'The best quality, beautiful and high-quality plastic bowls. Having professional bottom design with top classgrowers.

Heavy duty pot which is durable, long lasting, and elegantly stable.This pot has sufficient drainage holes at the bottom, which helps to avoid the overwatering to the plant.', N'Not Mention', 7, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (22, N'4.3 inch (11 cm) Flower Embossed Small Round Metal Watering Can Planter (Yellow)', 6.49, N'This very special and decorative planter adds a luxurious flair to its surroundings.

Brighten up your living room, kitchen, bedroom or even a office desk with beautiful flowers and plants in these stylish planters. This planter has very pleasing and unique design.', N'All types of indoor/outdoor, ornamental, decorative plants.', 8, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (23, N'2.8 inch (7 cm) Elephant Shape Marble Finish Ceramic Pot (Light Brown) (set of 2)', 6.98, N'Decorative Ceramic pots can impart a natural and beautiful look to any garden. Use these classic pots which are suitable for your requirement and provides considerable durability.

Ceramic Plants are best natural all around choice to grow plants. They come in variety of shapes and colors. Their classic yet unique look is so attractive that a true gardener can not deny its presence.

These ceramic pots are also little porous and allow air and water movement through the sides of the pot and are perfect where potting medium needs to be dried in less time to promote healthy root growth and avoid root rot. Create an exclusive decor and dont worry about the maintenance as ceramic pots are very easy to clean and almost free from discoloration.', N'Not Mention', 8, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (24, N'5.9 inch (15 cm) Warli Painting Cup Marble Finish Round Ceramic Pot (White) (set of 2)', 5.49, N'Decorative Ceramic pots can impart a natural and beautiful look to any garden. Use these classic pots which are suitable for your requirement and provides considerable durability.

Ceramic Plants are best natural all around choice to grow plants. They come in variety of shapes and colors. Their classic yet unique look is so attractive that a true gardener can not deny its presence.

These ceramic pots are also little porous and allow air and water movement through the sides of the pot and are perfect where potting medium needs to be dried in less time to promote healthy root growth and avoid root rot. Create an exclusive decor and dont worry about the maintenance as ceramic pots are very easy to clean and almost free from discoloration.', N'Not Mention', 8, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (25, N'6 inch (15 cm) Grower Round Plastic Pot (Black) (set of 6)', 2.29, N'Designed to bring color and vibrancy to your home/office interiors. It makes growing plants more fun.

These pots introduce new designs with latest color trends keeping in mind the increasing demand for planters for garden, terrace, indoor and outdoor plants.The opinion of customers, plant nurseries, architects, and professionals has been taken into consideration while selecting this range of pots.

This pot has sufficient drainage holes at the bottom, which helps to avoid the overwatering to the plant.', N'Not Mention', 9, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (26, N'3.3 inch (8 cm) Square Plastic Planter with Rounded Edges (Black) (Set of 6)', 2.59, N'Designed to bring color and vibrancy to your home/office interiors. It makes growing plants more fun.

These pots introduce new designs with latest color trends keeping in mind the increasing demand for planters for garden, terrace, indoor and outdoor plants.The opinion of customers, plant nurseries, architects, and professionals has been taken into consideration while selecting this range of pots.

This pot has sufficient drainage holes at the bottom, which helps to avoid the overwatering to the plant.', N'Not Mention', 9, N'.jpg')
GO
INSERT [dbo].[Plants] ([PlantID], [PlantName], [Price], [Description], [ItemFeature], [SubCategoryID], [Extension]) VALUES (27, N'23.6 inch (60 cm) Rectangle Plastic Microgreens Tray (3 mm) (Set of 2)', 3.49, N'This pack contains 2 units of Rectangle Plastic Microgreens Tray', N'Not Mention', 9, N'.jpg')
GO
SET IDENTITY_INSERT [dbo].[Plants] OFF
GO
SET IDENTITY_INSERT [dbo].[PlantReviews] ON 
GO
INSERT [dbo].[PlantReviews] ([PlantReviewID], [UserID], [ReviewDate], [ReviewTitle], [Address], [PlantID]) VALUES (1, N'leo@gmail.com', CAST(N'2021-06-23T23:11:47.4301858' AS DateTime2), N'Lovely Plants, But Very Small Containers', N'I had ordered five flowering plants, and they came very well packed indeed. All of them are doing well. Unfortunately, they were in very small containers, and hence had to be transplanted. Thankfully, the transplanting did not affect them. Hope Nursery Live takes note, and gives us slightly bigger pots for our plants.', 2)
GO
SET IDENTITY_INSERT [dbo].[PlantReviews] OFF
GO
