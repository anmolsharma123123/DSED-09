1. Open the Solution in Visual Studio

2. Build the project 

3. Navigate to tools ans select Nuget Package manager -> Package Manager Console (PMC)

4. On the console execute the following command
Update-Database

5. After migration is successful Run the project

6. There are two users

	i) Admin User

		User Name:- admin@gmail.com
		Password:-  Admins#5654

	ii) Registered User

		User Name:- leo@gmail.com
		Password:-  U$ser#5654
